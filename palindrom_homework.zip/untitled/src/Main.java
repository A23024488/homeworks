
public class Main {
    public static void main(String[] args) {
        String s = "arozaupalanalapuazora";
/*используем рекурсивный метод
задали название метода isPalindrome, если значение подтверждается, то YES, в остальных случаях NO
 */
        System.out.println(isPalindrome(s) ? "YES" : "NO");
    }

    private static boolean isPalindrome(String s) {
        if (s.length() == 1 || s.length() == 0)
            return true;   // если длина равна единице или нулю, то выражение является палиндромом

        if (s.charAt(0) == s.charAt(s.length() - 1))
            return isPalindrome(s.substring(1, s.length() - 1)); // использовали рекурсию
        /* если первый и последний элемент равны, то продолжаем вызывать палиндром
        так, постепенно урезаем количество букв на каждом шагу пока не останется 1 буква или пустой элемент
         */

        return false;
    }

}


